import 'package:flutter/material.dart';

class CartModel extends ChangeNotifier {
  //list of items on sale
  final List _shopItems = {
    // [itemName, itemPrice, imagePath, color]
    ["Avocado", "4.00", "lib/imgaes/avocado", Colors.green],
    ["Banana", "2.50", "lib/imgaes/banana", Colors.yellow],
    ["Chicken", "12.00", "lib/imgaes/chicken", Colors.brown],
    ["Water", "1.00", "lib/imgaes/water", Colors.blue],
  };
  get shopItems => _shopItems;
}
